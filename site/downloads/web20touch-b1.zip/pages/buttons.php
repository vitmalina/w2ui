<div class="toolbar">
	<h1>Buttons</h1>
	<a class="button back" onclick="jsTouch.loadPage('pages/home.php', { transition: 'slide-right' });"><span></span>Back</a>
</div>
<div class="content">
<div>
	<div style="padding: 10px;">
		<a href="javascript:" class="button-black" style="margin-top: 10px; width: 270px"> Black Button </a>
		<a href="javascript:" class="button-gray" style="margin-top: 10px; width: 270px"> Gray Button </a>
		<a href="javascript:" class="button-navy" style="margin-top: 10px; width: 270px"> Navy Button </a>
		<a href="javascript:" class="button-red" style="margin-top: 10px; width: 270px"> Red Button </a>
		<a href="javascript:" class="button-green" style="margin-top: 10px; width: 270px"> Green Button </a>
		<a href="javascript:" class="button-blue" style="margin-top: 10px; width: 270px"> Blue Button </a>
	</div>
</div>
</div>
