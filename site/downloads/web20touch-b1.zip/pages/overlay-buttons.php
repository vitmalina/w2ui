<div class="toolbar">
	<h1>Title</h1>
</div>
<div class="content" style="text-align: center; padding-top: 40px">
	<div>
		This is some message
	</div>
</div>
<div class="footer">
	<a href="javascript: alert('cannot save');" class="button-green" style="width: 110px;"> Save </a>
	<a href="javascript: jsTouch.overlayClose();" class="button-gray" style="width: 110px;"> Cancel </a>
</div>
