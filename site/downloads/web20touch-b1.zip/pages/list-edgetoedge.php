<div class="toolbar">
	<h1>EdgeToEdge List</h1>
	<a class="button back" onclick="jsTouch.loadPage('pages/lists.php', { transition: 'slide-right' });"><span></span>Back</a>
</div>
<div class="content">
<div>
	<div class="edgetoedge-title">A</div>
	<ul class="edgetoedge">
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 1<span class="count">4</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 2<span class="count">6</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 3<span class="arrow"></span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 4</a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 5<span class="count">10</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 6<span class="count">3</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 7<span class="count">7</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 8</a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 9<span class="arrow"></span></a></li>
	</ul>
	<div class="edgetoedge-title">B - names</div>
	<ul class="edgetoedge">
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 10<span class="count">45</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 11<span class="count">4</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 12<span class="count">6</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 13<span class="arrow"></span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 14</a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 15<span class="count">10</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 16<span class="count">3</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 17<span class="count">7</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 18</a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 19<span class="arrow"></span></a></li>
	</ul>
	<div class="edgetoedge-title">C</div>
	<ul class="edgetoedge">
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 20<span class="arrow"></span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 21<span class="count">4</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 22<span class="count">6</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 23<span class="arrow"></span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 24</a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 25<span class="count">10</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 26<span class="count">3</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 27<span class="count">7</span></a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 28</a></li>
		<li><a onclick="jsTouch.loadPage('pages/list-edgetoedge.php', { transition: 'slide-left' });">Item 29<span class="arrow"></span></a></li>
	</ul>
</div>
</div>
