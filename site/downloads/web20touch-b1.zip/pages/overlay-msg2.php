<div class="toolbar">
	<h1>Some Title</h1>
</div>
<div class="content">
<div>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean congue urna at lacus adipiscing 
	sollicitudin. Quisque quis venenatis leo. Etiam eu risus sit amet lectus auctor congue ut quis felis. 
	Suspendisse eu velit mattis elit dignissim adipiscing at dapibus ipsum. Curabitur pellentesque diam 
	non sapien elementum nec rutrum ligula egestas. Ut a sapien eget mauris elementum dignissim. Fusce 
	eu urna odio, vitae accumsan nisl. Suspendisse vel luctus lorem. Mauris mattis eros a ligula lacinia 
	sagittis. Ut faucibus tincidunt condimentum. Praesent lacus purus, ultrices ac fringilla a, 
	vestibulum eu enim. Fusce est ligula, suscipit a pellentesque vel, ornare sit amet turpis. 
	Suspendisse blandit blandit nibh ac pharetra. Nam ultrices consequat ipsum, non imperdiet quam 
	venenatis vel. Vivamus eros magna, feugiat quis bibendum nec, lobortis quis libero. Aenean elementum 
	condimentum tortor, et tempus turpis pulvinar at. Aliquam sed eros quam, eget tristique arcu. 
</div>
</div>