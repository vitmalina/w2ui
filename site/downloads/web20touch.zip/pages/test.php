<?
print_r($_GET);
?>