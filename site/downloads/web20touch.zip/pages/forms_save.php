<body style="background-color: white">
Data:<br>
<?
print("<pre>");
print_r($_POST);
?>
</body>
<script>
	alert(document.body.innerHTML);
</script>